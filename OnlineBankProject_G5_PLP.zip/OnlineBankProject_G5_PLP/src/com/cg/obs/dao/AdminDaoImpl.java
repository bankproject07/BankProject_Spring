package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.Transactions;
import com.cg.obs.exception.UserException;
import com.cg.obs.util.DBUtil;

public class AdminDaoImpl implements IAdminDao {

	Connection con;
	PreparedStatement pst;
	Statement st;
	public AdminDaoImpl(int i, String string, String string2, int j,
			String string3, String string4) {
		// TODO Auto-generated constructor stub
	}
	public AdminDaoImpl() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public List<Transactions> viewMonthlyReport(Date StartDate, Date EndDate) throws UserException
	{
		Transactions transaction = null;
		List<Transactions> tList = new ArrayList<>();
		
		try
		{
			con = DBUtil.getConnection();
			String select ="select * FROM  transaction WHERE (Dateoftransaction >= ?) AND (Dateoftransaction <= ?)";
			
			PreparedStatement pst = con.prepareStatement(select);
			System.out.println(select);
			pst.setDate(1, StartDate);
			pst.setDate(2, EndDate);
			ResultSet res = pst.executeQuery();
			while(res.next())
			{
				transaction=new Transactions();
				transaction.setTransaction_ID(res.getInt(1));
				transaction.setTran_Description(res.getString(2));
				transaction.setDateOfTransaction(res.getDate(3));
				transaction.setTransactionType(res.getString(4).charAt(0));
				transaction.setTransactionAmount(res.getDouble(5));
				transaction.setAccountID(res.getLong(6));
				tList.add(transaction);
				
			}
			
		}
		catch (SQLException e)
		{
			
			throw new UserException("Problem occured while getting transaction details");
			//e.printStackTrace();
		}
		
		finally
		{
			
			try {
				if(con!=null)
				{
				con.close();
				
				}
			}
			catch (SQLException e)
			{
				
				throw new UserException(e.getMessage());
			}
		}
		
		if(tList==null||tList.isEmpty())
		{
			throw new UserException("Transaction not Availble on that Date");
		}	
		return tList;
	}
	@Override
	public List<Transactions> viewYearlyReport(Date StartDate, Date EndDate) throws UserException {
		Transactions transaction = null;
		List<Transactions> tList = new ArrayList<>();
		
		try
		{
			con = DBUtil.getConnection();
			String select ="select * FROM  transaction WHERE (Dateoftransaction >= ?) AND (Dateoftransaction <= ?)";
			pst=con.prepareStatement(select);
			pst.setDate(1, StartDate);
			pst.setDate(2, EndDate);
			ResultSet res = pst.executeQuery();
			while(res.next())
			{
				transaction=new Transactions();
				transaction.setTransaction_ID(res.getInt(1));
				transaction.setTran_Description(res.getString(2));
				transaction.setDateOfTransaction(res.getDate(3));
				transaction.setTransactionType(res.getString(4).charAt(0));
				transaction.setTransactionAmount(res.getDouble(5));
				transaction.setAccountID(res.getLong(6));
				tList.add(transaction);
			}
			
		}
		catch (SQLException e)
		{	
			throw new UserException("Problem occured while getting transaction details");
			
		}
		if(tList==null||tList.isEmpty())
		{
			throw new UserException("Transaction not Availble on that Date");
		}
				
		return tList;

	}
	@Override
	public List<Transactions> viewDailyReport(Date StartDate) throws UserException {
		Transactions transaction = null;
		List<Transactions> tList = new ArrayList<>();
		
		try
		{
			con = DBUtil.getConnection();
			String select ="select * FROM  transaction WHERE (Dateoftransaction = ?)";
			pst=con.prepareStatement(select);
			pst.setDate(1, StartDate);
			ResultSet res = pst.executeQuery();
			while(res.next())
			{
				transaction=new Transactions();
				transaction.setTransaction_ID(res.getInt(1));
				transaction.setTran_Description(res.getString(2));
				transaction.setDateOfTransaction(res.getDate(3));
				transaction.setTransactionType(res.getString(4).charAt(0));
				transaction.setTransactionAmount(res.getDouble(5));
				transaction.setAccountID(res.getLong(6));
				tList.add(transaction);
			
			}
			
		}
		catch (SQLException e)
		{
			
			throw new UserException("Problem occured while getting transaction details");
			
		}
		if(tList==null||tList.isEmpty())
		{
			throw new UserException("Transaction not Availble on that Date");
		}
				
		return tList;

	}
	
	@Override
	public Admin getAdmin() throws UserException {
		Admin admin=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Admin";
			st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			rs.next();
			admin=new Admin();
			admin.setAdminid(rs.getString(1));
			admin.setAdminPassword(rs.getString(2));
			
		} catch (SQLException e) 
		{
			throw new UserException("Unable to retreive Admin Details");
		}
		return admin;
	}
	/*@Override
	public int addUsers(Customer customer, AccountMaster account) throws UserException
	{
		int accountid = -1;
		try
		{
			con=DBUtil.getConnection();
			String cust_seq="select custid_seq.nextVal from dual";
			ResultSet res = st.executeQuery(cust_seq);
			String acc_seq = "select accid_seq.nextVal from dual";
			st=con.createStatement();
			ResultSet rs = st.executeQuery(acc_seq);
			while(rs.next()==false)
			{
				throw new UserException("Error Occured while generating account id ");
			}
		
			int custid =rs.getInt(1);
			System.out.println(custid);
			String custname = customer.getCustomer_Name();
			String address = customer.getAddress();
			String mail = customer.getEmail();
			String pancard = customer.getPancard();
			
			//account master 
			int accid = rs.getInt(1);
			System.out.println(accid);
			String accountType = account.getAccountType();
			float balance = account.getAccount_bal();
			Date openDate = account.getOpen_date();
			
			String insert_cust ="insert into customer values (?,?,?,?,?)";
			String insert_accMaster ="insert into account_master values(?,?,?,?)";
			pst = con.prepareStatement(insert_accMaster);
			pst.setInt(1, custid);
			pst.setString(2, accountType);
			pst.setFloat(3, balance);
			pst.setDate(4, openDate);
			pst.executeQuery();
			
			pst= con.prepareStatement(insert_cust);
			pst.setInt(1, accid);
			pst.setString(2, custname);
			pst.setString(3, mail);
			pst.setString(4, address);
			pst.setString(5, pancard);
			pst.executeQuery();
			
			accountid = accid;
			
			
		}
		catch (SQLException e) 
		{	
			throw new UserException("Error occured while adding data : reason "+e.getMessage());
		}
		
		return accountid;
	}*/
	@Override
	public Customer getCustomerbyId(int id) throws UserException {
		Customer cust = null;
		try
		{
			con=DBUtil.getConnection();
			String sql="SELECT * FROM customer where customer_id=?";
			pst = con.prepareStatement(sql);
			pst.setInt(1, id);
		
			ResultSet res=pst.executeQuery();
		
			res.next();
			cust= new Customer();
			cust.setCustomer_ID(res.getInt(1));
			cust.setCustomer_Name(res.getString(2));
			cust.setEmail(res.getString(3));
			cust.setAddress(res.getString(4));
			cust.setPancard(res.getString(5));
		
			
			
		}
		catch (SQLException e)
		{
			throw new UserException("error while fetching data "+e.getMessage());
		}
	
		return cust;
	}
	@Override
	public int addUsers(Customer customer) throws UserException {
		
		int accountid = -1;
		try
		{
			con=DBUtil.getConnection();
			String cust_seq="select custid_seq.nextVal from dual";
			ResultSet res = st.executeQuery(cust_seq);
			
			while(res.next()==false)
			{
				throw new UserException("Error Occured while generating account id ");
			}
		
			int custid =res.getInt(1);
			System.out.println(custid);
			String custname = customer.getCustomer_Name();
			String address = customer.getAddress();
			String mail = customer.getEmail();
			String pancard = customer.getPancard();
			
			String insert_cust ="insert into customer values (?,?,?,?,?)";
			pst= con.prepareStatement(insert_cust);
			pst.setInt(1, custid);
			pst.setString(2, custname);
			pst.setString(3, mail);
			pst.setString(4, address);
			pst.setString(5, pancard);
			pst.executeQuery();
			
			accountid = custid;
			
			
		}
		catch (SQLException e) 
		{	
			throw new UserException("Error occured while adding data : reason "+e.getMessage());
		}
		
		return accountid;
	}
	@Override
	public int addUsers(AccountMaster accountMaster) throws UserException {
		int accountid = -1;
		try
		{
			con=DBUtil.getConnection();
			Customer cust = new Customer();
			
			long accid = accountMaster.getAccountId();
			int c_ID = accountMaster.getCustomerId();
			String accountType = accountMaster.getAccountType();
			double balance = accountMaster.getAccountBalance();
			Date openDate = accountMaster.getOpenDate();
			
			String insert_accMaster ="insert into account_master values(?,?,?,?,?)";
			pst = con.prepareStatement(insert_accMaster);
			pst.setLong(1, accid);
			pst.setInt(2, c_ID);
			pst.setString(3, accountType);
			pst.setDouble(4, balance);
			pst.setDate(5, openDate);
			pst.executeQuery();
			accountid = (int) accid;
			
			
		}
		catch (SQLException e) 
		{	
			throw new UserException("Error occured while adding data : reason "+ e.getMessage());
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		return accountid;
		
		
	}
	@Override
	public List<RequestTable> getAllRequest() throws UserException 
	{
		List<RequestTable> reqList = new ArrayList<>();
		RequestTable req = null;
		
		try
		{
			con = DBUtil.getConnection();
			String select = "select * from REQUESTTABLE";
			Statement pst = con.createStatement();
			
			ResultSet res = pst.executeQuery(select);
			while(res.next())
			{
				req= new RequestTable();
				
				req.setCustId(res.getInt(1));
				req.setType(res.getString(2));
				req.setAcc_id(res.getInt(3));
				reqList.add(req);
			}
			
			
		} 
		catch (SQLException e)
		{
			throw new UserException("Unable to fetch Request Details" + e.getMessage());
		}
		if(reqList == null || reqList.isEmpty())
		{
			throw new UserException("No Request Available");
		}
		return reqList;
	}
	@Override
	public boolean isCustomerExist(int id) throws UserException {
		

		boolean flag = false;
		
		
		try
		{
			con= DBUtil.getConnection();
			String selectQuery = "select count(*) from customer where  Customer_ID=?";
			pst = con.prepareStatement(selectQuery);
			pst.setInt(1, id);
			ResultSet res=pst.executeQuery();
			res.next();
			int count = res.getInt(1);			
			if(count == 1)
			{
				flag = true;
			}
			else
			{
				
				flag = false;
			}
				
		} 
		catch (SQLException e) 
		{
			throw new UserException("Invalid Consumer ID :"+e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			
		}
		
		return flag;
	}

}
