package com.cg.obs.junittest;

import static org.junit.Assert.*;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.obs.bean.AccountMaster;

public class TestAccountMaster {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAccountMasterLongStringIntDoubleDate() {
		
		try{
		DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
		Date d1 = (Date)df.parse("12-10-2011");
		
		AccountMaster master=new AccountMaster(11123,"Saving",105,40000,d1);
		assertNotNull(master);
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		
		}

}
